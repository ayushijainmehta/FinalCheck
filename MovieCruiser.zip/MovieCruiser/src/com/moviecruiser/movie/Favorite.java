package com.moviecruiser.movie;

public class Favorite {
	protected int id;
	protected int movieId;
	protected int userId;
	public Favorite(int id, int movieId, int userId) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.userId = userId;
	}
	public Favorite(int movieId, int userId) {
		super();
		
		this.movieId = movieId;
		this.userId = userId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
   
}

package com.moviecruiser.movie;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = "/customer")
//@WebServlet(urlPatterns = "/")
public class MovieServletCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MovieDAO movieDAO;
	public void init() {
	        movieDAO = new MovieDAO();
	    }
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
			    throws ServletException, IOException {
			        doGet(request, response);
			    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String action = request.getServletPath();
		  try {
	            switch (action) {
	               case "/favorite":
	                System.out.println("welcome to updation pafe");
	               addFavorite(request, response);
	                break;
	               case "/displayFavorite":
	            	  
	            	   System.out.println("Displaying Favorites"); 
	            	   listFavorite(request,response);
	            	   break;
	               case "/delete":
		            System.out.println("Deleting Favorites"); 
		            deleteUser(request,response);
	            	   break;
	                default:
	                    listMovies(request, response);
	                    break;
	            }
	        } catch (SQLException ex) {
	            throw new ServletException(ex);
	        }
		 
	}
	private void listFavorite(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException, ServletException {
		 List < Movie> listMovie = movieDAO.selectAllFavorites();
		 boolean exist = listMovie.isEmpty(); 
	     
	        	  request.setAttribute("listFavorite", listMovie);
	      		request.getRequestDispatcher("favorites.jsp").forward(request, response);
	    
	   
	
		    }
	private void addFavorite(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException
	{
	
		 int movieId= Integer.parseInt(request.getParameter("id"));
			int userId=1;//need to work on it
		
	        Favorite favorite=new Favorite(movieId,userId);
	        movieDAO.insertFavorite(favorite);
	        System.out.print("added favorite");
	     
	        List < Movie> listMovie = movieDAO.selectAllFavorites();
	        //request.setAttribute("listFavorite", listMovie);
      		//request.getRequestDispatcher("favoritesSuccess.jsp").forward(request, response);
	      // request.setAttribute("favorite", selectedFavorite);
response.sendRedirect("favoritesSuccess.jsp");
	}
	private void listMovies(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException, ServletException {
		 List < Movie> listMovie = movieDAO.selectAllMovies();
			
	        
	      request.setAttribute("listMovie", listMovie);
		request.getRequestDispatcher("movie-list-customer.jsp").forward(request, response);
		    }
	private void deleteUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
		        int id = Integer.parseInt(request.getParameter("id"));
		       movieDAO.deleteUser(id);
		        response.sendRedirect("favorites.jsp");

		    }
}
function validateForm()
{
    var username=document.forms["loginform"]["username"].value;  
    if(username==null || username=="" )
    {
        alert("name can't be left blank");
        return false;
    }

    var password=document.forms["loginform"]["password"].value;
    if(password==null || password=="")
    {
        alert("last name is mandatory");
        return false;
    }
    else
    {
        return true;
    }

}
package com.moviecruiser.movie;

public class DisplayFavorite {

	protected String title;
	protected String boxOffice;
	protected String genre;

	public DisplayFavorite(String title, String boxOffice, String genre) {
		super();
		this.title = title;
		this.boxOffice = boxOffice;
		this.genre = genre;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBoxOffice() {
		return boxOffice;
	}

	public void setBoxOffice(String boxOffice) {
		this.boxOffice = boxOffice;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

}
